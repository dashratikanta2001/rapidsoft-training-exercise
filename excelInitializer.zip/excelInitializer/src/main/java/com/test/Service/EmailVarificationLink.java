package com.test.Service;

public class EmailVarificationLink {

}
