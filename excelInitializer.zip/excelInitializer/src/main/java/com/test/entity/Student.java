package com.test.entity;

public class Student {

	private Integer id; 
	private String name;
	private Integer classNo;
	private String address;
	
}
