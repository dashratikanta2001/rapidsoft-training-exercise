package com.test.enums;

public enum UserType {
	ADMIN, CUSTOMER, MANAGER
}
