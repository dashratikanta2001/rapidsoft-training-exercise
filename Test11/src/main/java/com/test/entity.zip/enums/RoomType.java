package com.test.enums;

public enum RoomType {

	SINGLE_BED, DOUBLE_BED, DELUXE, SUITE
}
